# Lebse interactive prototype

Eight screens: Home, Explore, Product Detail, Seller Closet, Sell/Add Photos, Listing Details, Checkout, and Profile.

## Run

Install Node.js 22.12+ and run `npm install`, then `npm run dev` in the extracted project. Open the local address shown in the terminal. `npm run build` creates the production frontend in `dist/`.

## What works

- Responsive marketplace with reusable buttons, chips, badges, product and seller cards, fields, navigation, and modal bottom sheets.
- Search by item, brand, or seller; category, price, and size filters.
- Save and unsave pieces; follow closets and view a following feed.
- Product detail to checkout, validated delivery fields, payment-method selection, and simulated order confirmation.
- Local image upload, photo removal, required listing fields, and publication into your closet.
- Profile tabs for saved pieces, selling, and purchases.

## Design system

Warm cream #F8F5EE, dark brown #382C26, terracotta #A64E35, muted text #81776E, borders #DFD9CF. DM Sans with sans-serif fallback. Low corner radii, large 4:5 product photography, editorial headings, and open spacing. Reusable components are in src/components.jsx; design tokens and responsive rules are in src/styles.css; sample inventory is in src/data.js.

## Prototype boundaries

This is a frontend prototype, not a live marketplace. Orders do not charge money. Authentication, server storage, payment processing, delivery, messaging, and verification services are not connected. Seller reviews and inventory are sample content. Saved pieces, followed sellers, listings, and demo orders are stored in this browser's local storage. Uploaded listing covers are stored locally and may encounter browser storage limits. Photography loads from Unsplash and the font loads from Google Fonts, requiring an internet connection. No original approved design image was available in the conversation preview; implementation follows the approved written identity.

## Verification

Production build passed. In-app browser checks covered desktop at 1440×1000 and mobile at 390×844, image loading, saved-state changes, product navigation, seller follow, search results, mobile filter sheet, upload to Listing Details, and checkout through confirmed purchases. No browser errors or warnings were recorded. Mobile document width matched the viewport with no horizontal overflow. Listing publication was implemented but not exercised with the screenshot used as the temporary upload fixture.

Visual review checked cream/brown/terracotta palette, modern sans-serif typography, editorial spacing, low radii, product photography, and responsive navigation. Photo captions were corrected to match the red dress and crochet top. Explore search no longer silently filters Home.
